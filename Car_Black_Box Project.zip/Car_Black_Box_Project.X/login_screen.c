#include <xc.h>
#include <string.h>
#include <stdio.h>
#include "main.h"
#include "adc.h"
#include "clcd.h"
#include "ds1307.h"
#include "external_eeprom.h"
#include "main_menu.c"

void login_screen(unsigned char key)
{
    static char user_pass[5];
    char password[5];

    static unsigned char index = 0;
    static unsigned char attempt = 3;

    /* 0 -> Enter Password
       1 -> User Blocked */
    static unsigned char state = 0;

    static unsigned long blink_delay = 0;
    static unsigned char blink = 0;

    static unsigned long block_delay = 0;
    static unsigned char sec = 30;

    char str[17];
    unsigned char i;

    /* Read password from EEPROM */
    for(i = 0; i < 4; i++)
    {
        password[i] = read_external_eeprom(PASSWORD_ADDR + i);
    }
    password[4] = '\0';

    /*---------------- PASSWORD ENTRY ----------------*/
    if(state == 0)
    {
        clcd_print("ENTER PASSWORD ", LINE1(0));

        /* Cursor Blink */
        if(++blink_delay >= 1000)
        {
            blink_delay = 0;

            if(blink)
                clcd_putch(' ', LINE2(index));
            else
                clcd_putch('_', LINE2(index));

            blink ^= 1;
        }

        /* SW1 -> 1 */
        if((key == SW1) && (index < 4))
        {
            user_pass[index] = '1';
            clcd_putch('*', LINE2(index));
            index++;

            blink = 0;
            blink_delay = 0;
        }

        /* SW2 -> 0 */
        else if((key == SW2) && (index < 4))
        {
            user_pass[index] = '0';
            clcd_putch('*', LINE2(index));
            index++;

            blink = 0;
            blink_delay = 0;
        }

        /* Password Complete */
        if(index == 4)
        {
            user_pass[4] = '\0';

            if(strcmp(user_pass, password) == 0)
            {
                /* Login Successful */

                index = 0;
                attempt = 3;

                blink = 0;
                blink_delay = 0;

                clcd_print("                ", LINE1(0));
                clcd_print("                ", LINE2(0));

                operation = MAIN_MENU;
                return;
            }
            else
            {
                attempt--;

                index = 0;

                blink = 0;
                blink_delay = 0;

                clcd_print("                ", LINE2(0));

                if(attempt > 0)
                {
                    sprintf(str, "ATT LEFT : %u", attempt);

                    clcd_print(str, LINE1(0));

                    for(unsigned long d = 0; d < 300000; d++);

                    clcd_print("                ", LINE1(0));
                }
                else
                {
                    state = 1;
                    sec = 30;
                    block_delay = 0;

                    clcd_print("                ", LINE1(0));
                    clcd_print("                ", LINE2(0));
                }
            }
        }
    }

    /*---------------- USER BLOCKED ----------------*/
    else if(state == 1)
    {
        clcd_print("User Blocked    ", LINE1(0));

        sprintf(str, "Wait %2u Sec", sec);
        clcd_print(str, LINE2(0));

        if(++block_delay >= 35000)
        {
            block_delay = 0;

            if(sec > 0)
            {
                sec--;
            }

            if(sec == 0)
            {
                state = 0;
                attempt = 3;
                index = 0;

                blink = 0;
                blink_delay = 0;

                clcd_print("                ", LINE1(0));
                clcd_print("                ", LINE2(0));
            }
        }
    }
}
