/*
 * File:   main_menu.c
 * Author: USER
 *
 * Created on 5 July, 2026, 1:40 PM
 */

#include <xc.h>
#include <string.h>
#include <stdio.h>
#include "main.h"
#include "adc.h"
#include "clcd.h"
#include "ds1307.h"
#include "external_eeprom.h"

#define DASHBOARD          0
#define LOGIN_SCREEN       1
#define MAIN_MENU          2
#define VIEW_LOG           3
#define CLEAR_LOG          4
#define DOWNLOAD_LOG       5
#define SET_TIME           6
#define CHANGE_PASSWORD    7

#define PASSWORD_ADDR    0x70


char *menu[] =
{
    "View Log",
    "Clear Log",
    "Download Log",
    "Set Time",
    "Change Password"
};

unsigned char menu_pos = 0;
unsigned char operation = 0;
extern char data[10][17];

static unsigned char hour;
static unsigned char min;
static unsigned char sec;

unsigned char field = 0;      // 0-Hour, 1-Min, 2-Sec
unsigned int blink = 0;
unsigned char blink_flag = 0;

char time[9];



void main_menu(unsigned char key)
{
    key = read_digital_keypad(STATE);

    /* Display Menu */
    clcd_print("->", LINE1(0));
    clcd_print("  ", LINE2(0));

    if(menu_pos == 0)
    {
        clcd_print(menu[0], LINE1(2));
        clcd_print(menu[1], LINE2(2));
    }
    else if(menu_pos == 1)
    {
        clcd_print(menu[1], LINE1(2));
        clcd_print(menu[2], LINE2(2));
    }
    else if(menu_pos == 2)
    {
        clcd_print(menu[2], LINE1(2));
        clcd_print(menu[3], LINE2(2));
    }
    else if(menu_pos == 3)
    {
        clcd_print(menu[3], LINE1(2));
        clcd_print(menu[4], LINE2(2));
    }
    else if(menu_pos == 4)
    {
        clcd_print(menu[4], LINE1(2));
        clcd_print("                ", LINE2(0));
    }

    /* Scroll Down */
    if(key == SW1)
    {
        if(menu_pos < 4)
        {
            menu_pos++;
        }
    }

    /* Scroll Up */
    else if(key == SW2)
    {
        if(menu_pos > 0)
        {
            menu_pos--;
        }
    }

    /* Select Menu */
    else if(key == SW4)
    {
        switch(menu_pos)
        {
            case 0:
                operation = VIEW_LOG;
                break;

            case 1:
                operation = CLEAR_LOG;
                break;

            case 2:
                operation = DOWNLOAD_LOG;
                break;

            case 3:
                operation = SET_TIME;
                break;

            case 4:
                operation = CHANGE_PASSWORD;
                break;
        }
    }

    /* Exit to Dashboard */
    else if(key == SW5)
    {
        operation = DASHBOARD;
    }
}

void view_log(unsigned char key)
{
    static unsigned char index = 0;
    unsigned char i;
    unsigned char addr = 0;
    unsigned char count;

    key = read_digital_keypad(STATE);

    if(event_count == 0)
    {
        clcd_print("   NO LOGS     ", LINE1(0));
        clcd_print(" TO DISPLAY    ", LINE2(0));
        return;
    }

    count = event_count;

    /* Read all logs from EEPROM */
    addr = 0;
    for(i = 0; i < count; i++)
    {
        data[i][0] = i + '0';
        data[i][1] = ' ';

        data[i][2] = read_external_eeprom(addr++);
        data[i][3] = read_external_eeprom(addr++);
        data[i][4] = ':';
        data[i][5] = read_external_eeprom(addr++);
        data[i][6] = read_external_eeprom(addr++);
        data[i][7] = ':';
        data[i][8] = read_external_eeprom(addr++);
        data[i][9] = read_external_eeprom(addr++);

        data[i][10] = ' ';
        data[i][11] = read_external_eeprom(addr++);
        data[i][12] = read_external_eeprom(addr++);

        data[i][13] = ' ';
        data[i][14] = read_external_eeprom(addr++);
        data[i][15] = read_external_eeprom(addr++);

        data[i][16] = '\0';
    }

    /* Display Header */
    clcd_print("# TIME EV SP", LINE1(0));

    /* Display Current Log */
    clcd_print(data[index], LINE2(0));

    /* Next Log */
    if(key == SW1)
    {
        if(index < (count - 1))
        {
            index++;
        }
    }

    /* Previous Log */
    else if(key == SW2)
    {
        if(index > 0)
        {
            index--;
        }
    }

    /* Return to Main Menu */
    else if(key == SW5)
    {
        index = 0;
        operation = MAIN_MENU;
    }
}

 void clear_log(unsigned char key)
{
   
    /* Clear log count */
    event_count = 0;

  
    /* Display confirmation */
    clcd_print(" LOGS CLEARED  ", LINE1(0));
    clcd_print(" SUCCESS       ", LINE2(0));

    /* Delay */
    for(unsigned long d = 0; d < 500000; d++);

    /* Return to Main Menu */
    operation = MAIN_MENU;
}
 
 
 void download_log(void)
{
    unsigned char i;

    clcd_print("                ", LINE1(0));
    clcd_print("                ", LINE2(0));

    clcd_print("DOWNLOADING...", LINE1(1));

    if(event_count == 0)
    {
        clcd_print("NO LOGS", LINE2(4));

        for(unsigned long d = 0; d < 500000; d++);

        operation = MAIN_MENU;
        return;
    }

    uart_puts("\r\n");
    uart_puts("********************************\r\n");
    uart_puts("     CAR BLACK BOX LOGS\r\n");
    uart_puts("********************************\r\n");
    uart_puts("# TIME     EV SP\r\n");
    uart_puts("--------------------------------\r\n");

    for(i = 0; i < event_count; i++)
    {
        uart_puts(data[i]);
        uart_puts("\r\n");
    }

    uart_puts("--------------------------------\r\n");

    clcd_print("DOWNLOAD DONE", LINE2(1));

    for(unsigned long d = 0; d < 500000; d++);

    operation = MAIN_MENU;
}
 
 
void set_time(unsigned char key)
{
    /* Convert time to string */
    time[0] = (hour / 10) + '0';
    time[1] = (hour % 10) + '0';
    time[2] = ':';
    time[3] = (min / 10) + '0';
    time[4] = (min % 10) + '0';
    time[5] = ':';
    time[6] = (sec / 10) + '0';
    time[7] = (sec % 10) + '0';
    time[8] = '\0';

    clcd_print("SET TIME", LINE1(3));
    clcd_print(time, LINE2(4));

    /* Increase selected field */
    if(key == SW1)
    {
        if(field == 0)
        {
            hour++;
            if(hour > 23)
                hour = 0;
        }
        else if(field == 1)
        {
            min++;
            if(min > 59)
                min = 0;
        }
        else
        {
            sec++;
            if(sec > 59)
                sec = 0;
        }
    }

    /* Change selected field */
    else if(key == SW2)
    {
        field++;
        if(field > 2)
            field = 0;
    }

    /* Blink selected field */
    if(blink++ > 30000)
    {
        blink = 0;
        blink_flag ^= 1;
    }

    if(!blink_flag)
    {
        if(field == 0)
        {
            clcd_print("  ", LINE2(4));
        }
        else if(field == 1)
        {
            clcd_print("  ", LINE2(7));
        }
        else
        {
            clcd_print("  ", LINE2(10));
        }
    }

    /* Save time */
    if(key == SW4)
    {
        write_ds1307(HOUR_ADDR, ((hour / 10) << 4) | (hour % 10));
        write_ds1307(MIN_ADDR,  ((min  / 10) << 4) | (min  % 10));
        write_ds1307(SEC_ADDR,  ((sec  / 10) << 4) | (sec  % 10));

        operation = DASHBOARD;
    }

    /* Cancel */
    if(key == SW5)
    {
        operation = MAIN_MENU;
    }
}

 
  void change_password(unsigned char key)
{
    static unsigned char state = 0;
    static unsigned char index = 0;

    static char new_pass[5];
    static char confirm_pass[5];

    static unsigned int delay = 0;
    static unsigned char blink = 0;

    unsigned char i;

    /* Cursor Blink */
    if(delay++ > 50000)
    {
        delay = 0;
        blink ^= 1;
    }

    switch(state)
    {
        /* Enter New Password */
        case 0:

            clcd_print("ENTER NEW PASS", LINE1(0));

            if(blink)
                clcd_putch('_', LINE2(index));
            else
                clcd_putch(' ', LINE2(index));

            if(key == SW1 && index < 4)
            {
                new_pass[index] = '1';
                clcd_putch('*', LINE2(index));
                index++;
            }
            else if(key == SW2 && index < 4)
            {
                new_pass[index] = '0';
                clcd_putch('*', LINE2(index));
                index++;
            }

            if(index == 4)
            {
                new_pass[4] = '\0';

                state = 1;
                index = 0;

                clcd_print("                ", LINE1(0));
                clcd_print("                ", LINE2(0));
            }

            break;

        /* Confirm Password */
        case 1:

            clcd_print("CONFIRM PASS", LINE1(0));

            if(blink)
                clcd_putch('_', LINE2(index));
            else
                clcd_putch(' ', LINE2(index));

            if(key == SW1 && index < 4)
            {
                confirm_pass[index] = '1';
                clcd_putch('*', LINE2(index));
                index++;
            }
            else if(key == SW2 && index < 4)
            {
                confirm_pass[index] = '0';
                clcd_putch('*', LINE2(index));
                index++;
            }

            if(index == 4)
            {
                confirm_pass[4] = '\0';

                if(strcmp(new_pass, confirm_pass) == 0)
                {
                    for(i = 0; i < 4; i++)
                    {
                        write_external_eeprom(PASSWORD_ADDR + i,
                                              new_pass[i]);
                    }

                    clcd_print(" PASSWORD      ", LINE1(0));
                    clcd_print(" CHANGED       ", LINE2(0));

                    for(unsigned long d = 0; d < 500000; d++);

                    state = 0;
                    index = 0;
                    operation = MAIN_MENU;
                }
                else
                {
                    clcd_print(" PASS MISMATCH ", LINE1(0));
                    clcd_print("  TRY AGAIN    ", LINE2(0));

                    for(unsigned long d = 0; d < 500000; d++);

                    state = 0;
                    index = 0;
                    operation = MAIN_MENU;
                }
            }

            break;
    }
}
       
   
 
    