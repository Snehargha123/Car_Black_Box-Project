#pragma config WDTE = OFF // Disable Watchdog Timer

#include "main.h"

#define DASHBOARD          0
#define LOGIN_SCREEN       1
#define MAIN_MENU          2
#define VIEW_LOG           3
#define CLEAR_LOG          4
#define DOWNLOAD_LOG       5
#define SET_TIME           6
#define CHANGE_PASSWORD    7

/* Definition of Shared Global State Variables */
unsigned char operation = DASHBOARD; 
unsigned int event_count = 0;


void init_config(void)
{
    init_adc();
    init_clcd();
    init_digital_keypad();
    init_i2c(100000); // 100KHz standard I2C operation
    init_ds1307();
    init_uart(9600);   // Pass appropriate baudrate missing in original config
}

void main(void) 
{
    init_config();
    unsigned char key;
    
    while(1)
{
    key = read_digital_keypad(STATE);

    switch(operation)
    {
        case DASHBOARD:
            dashboard(key);
            break;

        case LOGIN_SCREEN:
            login_screen(key);
            break;

        case MAIN_MENU:
            main_menu(key);
            break;

        case VIEW_LOG:
            view_log(key);
            break;

        case CLEAR_LOG:
            clear_log(key);
            break;

        case DOWNLOAD_LOG:
            download_log();
            break;

        case SET_TIME:
            set_time(key);
            break;

        case CHANGE_PASSWORD:
            change_password(key);
            break;
    }
}
}