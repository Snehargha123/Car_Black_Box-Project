#include <xc.h>
#include "uart.h"

void init_uart(unsigned long baud)
{
    /* Enable Serial Port */
    SPEN = 1;

    /* Enable Continuous Reception */
    CREN = 1;

    /* Enable Transmission */
    TXEN = 1;

    /* High Speed Baud Rate */
    BRGH = 1;

    /* Baud Rate */
    SPBRG = ((FOSC / (16UL * baud)) - 1);

    /* Enable UART Receive Interrupt */
    RCIE = 1;
}

unsigned char uart_getchar(void)
{
    while(RCIF == 0);

    RCIF = 0;

    return RCREG;
}

void uart_putchar(unsigned char data)
{
    while(TXIF == 0);
    TXREG = data;
}

void uart_puts(const char *str)
{
    while(*str)
        uart_putchar(*str++);
}