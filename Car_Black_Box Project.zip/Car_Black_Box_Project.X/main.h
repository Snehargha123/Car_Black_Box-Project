#ifndef MAIN_H
#define MAIN_H

#include <xc.h>
#include <string.h>
#include <stdio.h>

#include "adc.h"
#include "digital_keypad.h"
#include "clcd.h"
#include "i2c.h"
#include "ds1307.h"
#include "external_eeprom.h"
#include "uart.h"

#define DASHBOARD          0
#define LOGIN_SCREEN       1
#define MAIN_MENU          2
#define VIEW_LOG           3
#define CLEAR_LOG          4
#define DOWNLOAD_LOG       5
#define SET_TIME           6
#define CHANGE_PASSWORD    7

/*Password EEPROM Address --------------------*/
#define PASSWORD_ADDR      0x70


extern unsigned char operation;
extern unsigned int event_count;
extern unsigned char menu_pos;

extern unsigned char clock_reg[9];
extern unsigned char speed[3];
extern char data[10][17];

void dashboard(unsigned char key);
void store_event(void);

void login_screen(unsigned char key);

void main_menu(unsigned char key);

void view_log(unsigned char key);
void clear_log(unsigned char key);
void download_log(void);
void set_time(unsigned char key);
void change_password(unsigned char key);

/*-------------------- RTC --------------------*/
void get_time(unsigned char *clock_reg);
void display_time(unsigned char *clock_reg);

#endif /* MAIN_H */AIN_H */