/*
 * File:   dashboard.c
 * Author: 25014
 *
 * Created on 31 December, 2025
 */
#include <xc.h>
#include <string.h>
#include "main.h"
#include "adc.h"
#include "clcd.h"
#include "ds1307.h"
#include "external_eeprom.h"


void store_event(void);
unsigned char clock_reg[9], speed[3] = {0};
char  *event[ ] = { "ON",  "GN", "G1", "G2", "G3", "G4", "GR", "C"};   //array of strings consists of collection of events to display event
unsigned int pos = 0;  //increase or decrease the position of array based on change of gear change
unsigned int adc_val; //Need to store the value of ADC to display speed on CLCD
unsigned int event_count = 0;


void dashboard(unsigned char key)
{
    clcd_print(" TIME     EV SP", LINE1(0));

    get_time(clock_reg);
    display_time(clock_reg);

    if(key == SW1)
    {
        if(pos == 7)
            pos = 1;

        if(pos < 6)
        {
            pos++;
            store_event();
        }
    }
    else if(key == SW2)
    {
        if(pos == 7)
            pos = 1;

        if(pos > 1)
        {
            pos--;
            store_event();
        }
    }
    else if(key == SW3)
    {
        pos = 7;
        store_event();
    }
    else if(key == SW4)
    {
        operation = LOGIN_SCREEN;
        return;
    }

    adc_val = read_adc(CHANNEL0) / 10.23;

    speed[0] = (adc_val / 10) + '0';
    speed[1] = (adc_val % 10) + '0';
    speed[2] = '\0';

    clcd_print(event[pos], LINE2(10));
    clcd_print((char *)speed, LINE2(14));
  }
     



        void store_event(void)       //storing log in external eeprom
        {
           static int address = 0x00;
           unsigned char i;

           for(i = 0; i < 8; i++)
          {
            if(i == 2 || i == 5)
            continue;

            write_external_eeprom(address++, clock_reg[i]);
          }

           write_external_eeprom(address++, event[pos][0]);
           write_external_eeprom(address++, event[pos][1]);

           write_external_eeprom(address++, speed[0]);
           write_external_eeprom(address++, speed[1]);

          if(address > 0x99)
              address = 0x00;

         if(event_count < 10)
            event_count++;
       }